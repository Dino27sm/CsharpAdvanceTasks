﻿namespace T05.GenericCountMethodString
{
    using System;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            Box<string> boxObject = new Box<string>();
            int numItems = int.Parse(Console.ReadLine());
            for (int i = 0; i < numItems; i++)
            {
                string readLine = Console.ReadLine();
                boxObject.BoxList.Add(readLine);
            }
            string target = Console.ReadLine();
            Console.WriteLine(boxObject.GetGreaterThan(target));
        }
    }
}
