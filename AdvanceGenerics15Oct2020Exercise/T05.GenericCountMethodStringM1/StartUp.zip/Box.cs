﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace T05.GenericCountMethodStringM1
{
    public class Box<T>
        where T : IComparable
    {
        public Box()
        {
            this.BoxList = new List<T>();
        }
        public List<T> BoxList { get; set; }
        public int GetGreaterThan(T compareTarget)
        {
            return this.BoxList.Where(x => x.CompareTo(compareTarget) > 0).Count();
        }
    }
}
