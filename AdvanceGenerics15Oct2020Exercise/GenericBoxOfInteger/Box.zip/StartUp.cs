﻿namespace GenericBoxOfInteger
{
    using System;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            int numLines = int.Parse(Console.ReadLine());
            for (int i = 0; i < numLines; i++)
            {
                int readLine = int.Parse(Console.ReadLine());
                Box<int> boxObject = new Box<int>(readLine);
                Console.WriteLine($"{boxObject}");
            }
        }
    }
}
