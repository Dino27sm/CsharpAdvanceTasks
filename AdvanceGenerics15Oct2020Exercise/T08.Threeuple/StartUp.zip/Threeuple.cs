﻿namespace T08.Threeuple
{
    public class Threeuple<T1, T2, T3>
    {
        public Threeuple(T1 elementOne, T2 elementTwo, T3 elementThree)
        {
            this.FirstElement = elementOne;
            this.SecondElement = elementTwo;
            this.ThirdElement = elementThree;
        }
        public T1 FirstElement { get; set; }
        public T2 SecondElement { get; set; }
        public T3 ThirdElement { get; set; }

        public override string ToString()
        {
            return $"{this.FirstElement} -> {this.SecondElement} -> {this.ThirdElement}";
        }
    }
}
