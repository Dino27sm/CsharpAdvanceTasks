﻿namespace T08.Threeuple
{
    using System;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            string[] nameAndAddressTown = Console.ReadLine().Split();
            string fullName = $"{nameAndAddressTown[0]} {nameAndAddressTown[1]}";
            string address = nameAndAddressTown[2];
            string town = nameAndAddressTown[3];
            if (nameAndAddressTown.Length > 4)
            {
                town = town + " " + nameAndAddressTown[4];
            }

            string[] nameAndBeerDrunk = Console.ReadLine().Split();
            string name = nameAndBeerDrunk[0];
            int beerLiters = int.Parse(nameAndBeerDrunk[1]);
            bool isDrunk = false;
            if (nameAndBeerDrunk[2] == "drunk")
                isDrunk = true;

            string[] nameAccBank = Console.ReadLine().Split();
            string userName = nameAccBank[0];
            double accountBalance = double.Parse(nameAccBank[1]);
            string bankName = nameAccBank[2];

            Threeuple<string, string, string> firstLine = new Threeuple<string, string, string>(fullName, address, town);
            Threeuple<string, int, bool> secondLine = new Threeuple<string, int, bool>(name, beerLiters, isDrunk);
            Threeuple<string, double, string> thirdLine = new Threeuple<string, double, string>(userName, accountBalance, bankName);

            Console.WriteLine(firstLine);
            Console.WriteLine(secondLine);
            Console.WriteLine(thirdLine);
        }
    }
}
