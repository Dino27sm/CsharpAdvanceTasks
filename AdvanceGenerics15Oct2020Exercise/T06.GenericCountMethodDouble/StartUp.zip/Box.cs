﻿using System;
using System.Collections.Generic;

namespace T06.GenericCountMethodDouble
{
    public class Box<T>
        where T : IComparable
    {
        public Box()
        {
            this.BoxList = new List<T>();
        }
        public List<T> BoxList { get; set; }
        public int GetGreaterThan(T compareTarget)
        {
            int counter = 0;
            foreach (T item in this.BoxList)
            {
                if (item.CompareTo(compareTarget) > 0)
                {
                    counter++;
                }
            }
            return counter;
        }
    }
}
