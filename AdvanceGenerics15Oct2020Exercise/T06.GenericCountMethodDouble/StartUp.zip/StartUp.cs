﻿namespace T06.GenericCountMethodDouble
{
    using System;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            Box<double> boxObject = new Box<double>();
            int numItems = int.Parse(Console.ReadLine());
            for (int i = 0; i < numItems; i++)
            {
                double readLine = double.Parse(Console.ReadLine());
                boxObject.BoxList.Add(readLine);
            }
            double target = double.Parse(Console.ReadLine());
            Console.WriteLine(boxObject.GetGreaterThan(target));
        }
    }
}
