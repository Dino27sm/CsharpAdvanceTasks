﻿namespace T04.GenericSwapMethodIntegers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            List<int> textData = new List<int>();
            int numItems = int.Parse(Console.ReadLine());
            for (int i = 0; i < numItems; i++)
            {
                int readLine = int.Parse(Console.ReadLine());
                textData.Add(readLine);
            }
            int[] swapInfo = Console.ReadLine().Split().Select(int.Parse).ToArray();
            int indexOne = swapInfo[0];
            int indexTwo = swapInfo[1];
            List<int> printList = SwapElements(textData, indexOne, indexTwo);
            foreach (var item in printList)
            {
                Console.WriteLine($"{item.GetType()}: {item}");
            }
        }

        public static List<T> SwapElements<T>(List<T> inpList, int index1, int index2)
        {
            List<T> outList = inpList.ToList();
            T temp = outList[index1];
            outList[index1] = outList[index2];
            outList[index2] = temp;
            return outList;
        }
    }
}
