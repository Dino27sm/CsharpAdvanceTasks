﻿namespace T07.Tuple
{
    public class Tuple<T1, T2>
    {
        public Tuple(T1 elementOne, T2 elementTwo)
        {
            this.FirstElement = elementOne;
            this.SecondElement = elementTwo;
        }
        public T1 FirstElement { get; set; }
        public T2 SecondElement { get; set; }

        public override string ToString()
        {
            return $"{this.FirstElement} -> {this.SecondElement}";
        }
    }
}
