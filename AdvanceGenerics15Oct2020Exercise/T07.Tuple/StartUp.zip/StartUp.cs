﻿namespace T07.Tuple
{
    using System;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            string[] nameAndAddress = Console.ReadLine().Split();
            string fullName = $"{nameAndAddress[0]} {nameAndAddress[1]}";
            string address = nameAndAddress[2];

            string[] nameAndBeer = Console.ReadLine().Split();
            string name = nameAndBeer[0];
            int beerLiters = int.Parse(nameAndBeer[1]);

            string[] twoNumbers = Console.ReadLine().Split();
            int numOne = int.Parse(twoNumbers[0]);
            double numTwo = double.Parse(twoNumbers[1]);

            Tuple<string, string> firstLine = new Tuple<string, string>(fullName, address);
            Tuple<string, int> secondLine = new Tuple<string, int>(name, beerLiters);
            Tuple<int, double> thirdLine = new Tuple<int, double>(numOne, numTwo);
            Console.WriteLine(firstLine);
            Console.WriteLine(secondLine);
            Console.WriteLine(thirdLine);
        }
    }
}
