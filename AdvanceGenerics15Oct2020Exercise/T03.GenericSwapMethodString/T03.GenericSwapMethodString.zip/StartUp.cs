﻿namespace T03.GenericSwapMethodString
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            List<string> textData = new List<string>();
            int numItems = int.Parse(Console.ReadLine());
            for (int i = 0; i < numItems; i++)
            {
                string readLine = Console.ReadLine();
                textData.Add(readLine);
            }
            int[] swaoInfo = Console.ReadLine().Split().Select(int.Parse).ToArray();
            int indexOne = swaoInfo[0];
            int indexTwo = swaoInfo[1];
            List<string> printList = SwapElements(textData, indexOne, indexTwo);
            foreach (var item in printList)
            {
                Console.WriteLine($"{item.GetType()}: {item}");
            }

        }
        public static List<T> SwapElements<T>(List<T> inpList, int index1, int index2)
        {
            List<T> outList = inpList.ToList();
            T temp = outList[index1];
            outList[index1] = outList[index2];
            outList[index2] = temp;
            return outList;
        }
    }
}
