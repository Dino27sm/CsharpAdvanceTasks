﻿namespace GenericBoxOfString
{
    using System;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            int numLines = int.Parse(Console.ReadLine());
            for (int i = 0; i < numLines; i++)
            {
                string readLine = Console.ReadLine();
                Box<string> boxObject = new Box<string>(readLine);
                Console.WriteLine($"System.String: {boxObject}");
            }
        }
    }
}
