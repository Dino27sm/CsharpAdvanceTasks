﻿namespace GenericBoxOfString
{
    public class Box<T>
    {
        public Box(T boxInput)
        {
            this.BoxValue = boxInput;
        }
        public T BoxValue { get; set; }

        public override string ToString()
        {
            return this.BoxValue.ToString();
        }
    }
}
