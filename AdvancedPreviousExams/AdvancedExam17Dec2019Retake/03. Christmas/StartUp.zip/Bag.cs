﻿using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Christmas
{
    public class Bag
    {
        private List<Present> data;

        public Bag(string color, int capacity)
        {
            this.Color = color;
            this.Capacity = capacity;
            this.data = new List<Present>();
        }
        public string Color { get; set; }
        public int Capacity { get; set; }
        public int Count { get { return this.data.Count; } }

        public void Add(Present present)
        {
            if (this.Count < this.Capacity)
                this.data.Add(present);
        }

        public bool Remove(string name)
        {
            return this.data.Remove(this.data.Find(x => x.Name == name));
        }

        public Present GetHeaviestPresent()
        {
            double maxWeight = this.data.Select(x => x.Weight).Max();
            return this.data.Find(x => x.Weight == maxWeight);
        }

        public Present GetPresent(string name)
        {
            return this.data.Find(x => x.Name == name);
        }

        public string Report()
        {
            StringBuilder sbPrint = new StringBuilder();
            sbPrint.AppendLine($"{this.Color} bag contains:");
            foreach (var item in this.data)
            {
                sbPrint.AppendLine($"{item}");
            }
            return sbPrint.ToString().Trim();
        }
    }
}
