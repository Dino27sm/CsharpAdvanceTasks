﻿
namespace VetClinic
{
    public class Pet
    {
        public Pet(string petName, int petAge, string ownerName)
        {
            this.Name = petName;
            this.Age = petAge;
            this.Owner = ownerName;
        }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Owner { get; set; }

        public override string ToString()
        {
            return $"Name: {this.Name} Age: {this.Age} Owner: {this.Owner}";
        }
    }
}
