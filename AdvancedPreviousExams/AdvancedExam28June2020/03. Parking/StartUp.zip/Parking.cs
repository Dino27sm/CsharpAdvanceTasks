﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System;

namespace Parking
{
    public class Parking
    {
        private List<Car> dataCar; 

        public Parking(string type, int capacity)
        {
            this.Type = type;
            this.Capacity = capacity;
            this.dataCar = new List<Car>();
        }

        public string  Type { get; set; }
        public int Capacity { get; set; }

        public int Count
        {
            get
            {
                return this.dataCar.Count;
            }
        }

        public void Add(Car car)
        {
            if (this.Capacity - this.dataCar.Count > 0)
            {
                this.dataCar.Add(car);
            }
        }

        public bool Remove(string manufacturer, string model)
        {
            bool isRemoved = false;
            for (int i = 0; i < this.dataCar.Count; i++)
            {
                if (this.dataCar[i].Manufacturer == manufacturer  && this.dataCar[i].Model == model)
                {
                    this.dataCar.RemoveAll(x => x.Manufacturer == manufacturer && x.Model == model);
                    isRemoved = true;
                }
            }
            return isRemoved;
        }

        public Car GetLatestCar()
        {
            Car latestCar = this.dataCar.Find(x => x.Year == this.dataCar.Select(y => y.Year).Max());
            return latestCar;
        }

        public Car GetCar(string manufacturer, string model)
        {
            return this.dataCar.Find(x => x.Manufacturer == manufacturer && x.Model == model);
        }

        public string GetStatistics()
        {
            StringBuilder printStatistics = new StringBuilder();
            printStatistics.AppendLine($"The cars are parked in {this.Type}:");
            foreach (var item in this.dataCar)
            {
                printStatistics.AppendLine($"{item.Manufacturer} {item.Model} ({item.Year})");
            }
            return printStatistics.ToString().Trim();
        }
    }
}
