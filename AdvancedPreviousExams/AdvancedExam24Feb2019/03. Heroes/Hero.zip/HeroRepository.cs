﻿using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Heroes
{
    public class HeroRepository
    {
        private List<Hero> data;
        public HeroRepository()
        {
            this.data = new List<Hero>();
        }

        public int Count { get { return this.data.Count; } }

        public void Add(Hero hero)
        {
            this.data.Add(hero);
        }

        public bool Remove(string name)
        {
            return this.data.Remove(this.data.Find(x => x.Name == name));
        }
        
        public Hero GetHeroWithHighestStrength()
        {
            int maxStrength = this.data.Select(x => x.Item.Strength).ToArray().Max();
            return this.data.Find(x => x.Item.Strength == maxStrength);
        }
        public Hero GetHeroWithHighestAbility()
        {
            int maxAbility = this.data.Select(x => x.Item.Ability).ToArray().Max();
            return this.data.Find(x => x.Item.Ability == maxAbility);
        }
        public Hero GetHeroWithHighestIntelligence()
        {
            int maxIntelligence = this.data.Select(x => x.Item.Intelligence).ToArray().Max();
            return this.data.Find(x => x.Item.Intelligence == maxIntelligence);
        }

        public override string ToString()
        {
            StringBuilder sbRepository = new StringBuilder();
            foreach (var hero in this.data)
            {
                sbRepository.AppendLine(hero.ToString());
            }
            return sbRepository.ToString().Trim();
        }
    }
}
