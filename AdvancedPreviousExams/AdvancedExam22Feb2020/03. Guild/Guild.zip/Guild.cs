﻿
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Guild
{
    public class Guild
    {
        private List<Player> roster;

        public Guild(string nameGuild, int capacity)
        {
            this.Name = nameGuild;
            this.Capacity = capacity;
            this.roster = new List<Player>();
        }
        public string Name { get; set; }
        public int Capacity { get; set; }
        public int Count { get { return this.roster.Count; } }

        public void AddPlayer(Player player)
        {
            if (this.Count < this.Capacity)
                this.roster.Add(player);
        }
        public bool RemovePlayer(string name) => this.roster.Remove(this.roster.Find(x => x.Name == name));
        public void PromotePlayer(string name)
        {
            Player toPromote = this.roster.Find(x => x.Name == name);
            if (toPromote != null)
                toPromote.Rank = "Member";
        }
        public void DemotePlayer(string name)
        {
            Player toDemote = this.roster.Find(x => x.Name == name);
            if (toDemote != null)
                toDemote.Rank = "Trial";
        }
        public Player[] KickPlayersByClass(string className)
        {
            List<Player> kickPlayers = new List<Player>(this.roster);
            kickPlayers.RemoveAll(x => x.Class != className);
            this.roster.RemoveAll(x => x.Class == className);
            return kickPlayers.ToArray();
        }
        public string Report()
        {
            StringBuilder sbReport = new StringBuilder();
            sbReport.AppendLine($"Players in the guild: {this.Name}");
            foreach (var item in this.roster)
                sbReport.AppendLine($"{item.ToString()}");
            return sbReport.ToString().Trim();
        }
    }
}
