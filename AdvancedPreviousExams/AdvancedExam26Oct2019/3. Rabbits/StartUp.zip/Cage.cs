﻿using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rabbits
{
    public class Cage
    {
        private List<Rabbit> data;
        public Cage(string name, int capacity)
        {
            this.Name = name;
            this.Capacity = capacity;
            this.data = new List<Rabbit>();
        }

        public string Name { get; set; }
        public int Capacity { get; set; }
        public int Count => this.data.Count;

        public void Add(Rabbit rabbit)
        {
            if (this.Count < this.Capacity)
                this.data.Add(rabbit);
        }

        public bool RemoveRabbit(string name)
        {
            return this.data.Remove(this.data.Find(x => x.Name == name));
        }

        public void RemoveSpecies(string species)
        {
            this.data.RemoveAll(x => x.Species == species);
        }

        public Rabbit SellRabbit(string name)
        {
            Rabbit soldRabbit = this.data.Find(x => x.Name == name);
            soldRabbit.Available = false;
            return soldRabbit;
        }

        public Rabbit[] SellRabbitsBySpecies(string species)
        {
            foreach (var rabit in this.data)
            {
                if (rabit.Species == species)
                    rabit.Available = false;
            }
            Rabbit[] rabitsSold = this.data.Where(x => x.Species == species).ToArray();
            return rabitsSold;
        }

        public string Report()
        {
            StringBuilder sbPrint = new StringBuilder();
            sbPrint.AppendLine($"Rabbits available at {this.Name}:");
            foreach (var item in this.data.Where(x => x.Available == true))
            {
                sbPrint.AppendLine($"{item}");
            }
            return sbPrint.ToString().Trim();

        }
    }
}
