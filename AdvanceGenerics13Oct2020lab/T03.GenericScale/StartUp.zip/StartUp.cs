﻿using System;
using System.Runtime.InteropServices;

namespace GenericScale
{
    class StartUp
    {
        static void Main(string[] args)
        {
            EqualityScale<int> testOne = new EqualityScale<int>(3, 2);
            var getResult = testOne.AreEqual();
            Console.WriteLine(getResult);
        }
    }
}
