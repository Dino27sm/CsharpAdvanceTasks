﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericScale
{
    class EqualityScale<T>
    {
        private T leftOne;
        private T rightOne;
        public EqualityScale(T left, T right)
        {
            this.leftOne = left;
            this.rightOne = right;
        }

        public bool AreEqual()
        {
            bool result = this.leftOne.Equals(this.rightOne);
            return result;
        }
    }
}
