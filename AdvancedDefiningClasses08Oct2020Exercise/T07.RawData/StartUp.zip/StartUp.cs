﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            List<Car> carsDataList = new List<Car>();
            int numCars = int.Parse(Console.ReadLine());
            for (int i = 0; i < numCars; i++)
            {
                string[] readCarsInfo = Console.ReadLine().Split();
                Car carCreate = new Car(readCarsInfo);
                carsDataList.Add(carCreate);
            }

            string getCommand = Console.ReadLine();
            if(getCommand == "fragile")
            {
                carsDataList = carsDataList.Where(x => x.CarCargo.CargoType == getCommand)
                .Where(y => y.CarTires.Any(z => z.TirePressure < 1.0))
                .ToList();
            }
            else if (getCommand == "flamable")
            {
                carsDataList = carsDataList.Where(x => x.CarCargo.CargoType == getCommand)
                .Where(y => y.CarEngine.EnginePower > 250)
                .ToList();
            }
            foreach (Car item in carsDataList)
            {
                Console.WriteLine(item.CarModel);
            }
        }
    }
}
