﻿
namespace DefiningClasses
{
    public class Car
    {
        public Car(string[] carData)
        {
            this.CarModel = carData[0];
            this.CarEngine = new Engine(int.Parse(carData[1]), int.Parse(carData[2]));
            this.CarCargo = new Cargo(int.Parse(carData[3]), carData[4]);
            this.CarTires[0] = new Tire(double.Parse(carData[5]), int.Parse(carData[6]));
            this.CarTires[1] = new Tire(double.Parse(carData[7]), int.Parse(carData[8]));
            this.CarTires[2] = new Tire(double.Parse(carData[9]), int.Parse(carData[10]));
            this.CarTires[3] = new Tire(double.Parse(carData[11]), int.Parse(carData[12]));
        }
        public string CarModel { get; set; }
        public Engine CarEngine { get; set; }
        public Cargo CarCargo { get; set; }
        public Tire[] CarTires { get; set; } = new Tire[4];
    }
}
