﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class DateModifier
    {
        public double DaysBetweenDates(string dateOne, string dateTwo)
        {
            DateTime firstDate = DateTime.Parse(dateOne);
            DateTime secondDate = DateTime.Parse(dateTwo);

            double difference = (secondDate - firstDate).TotalDays;
            double numDays = Math.Abs(difference);
            return numDays;
        }
    }
}
