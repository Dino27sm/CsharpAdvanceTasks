﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string readDateOne = Console.ReadLine();
            string readDateTwo = Console.ReadLine();

            DateModifier dayDistace = new DateModifier();
            double daysResult = dayDistace.DaysBetweenDates(readDateOne, readDateTwo);
            Console.WriteLine(daysResult);
        }
    }
}
