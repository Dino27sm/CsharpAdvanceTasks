﻿
namespace DefiningClasses
{
    public class Pokemon
    {
        public Pokemon(string name, string element, int health )
        {
            this.NamePokemon = name;
            this.ElementPokemon = element;
            this.HealthPokemon = health;
        }
        public string NamePokemon { get; set; }
        public string ElementPokemon { get; set; }
        public int HealthPokemon { get; set; }
    }
}
