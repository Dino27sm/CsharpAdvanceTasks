﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            List<Trainer> trainersList = new List<Trainer>();
            string readData = "";
            while ((readData = Console.ReadLine()) != "Tournament")
            {
                string[] dataParts = readData.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string trainerName = dataParts[0];
                string pokemonName = dataParts[1];
                string pokemonElement = dataParts[2];
                int pokemonHealth = int.Parse(dataParts[3]);
                Pokemon pokemonObject = new Pokemon(pokemonName, pokemonElement, pokemonHealth);
                if (trainersList.Contains(trainersList.Find(x => x.TrainerName == trainerName)))
                {
                    trainersList.Find(x => x.TrainerName == trainerName).Pokemons.Add(pokemonObject);
                }
                else
                {
                    Trainer trainerObject = new Trainer(trainerName, pokemonObject);
                    trainersList.Add(trainerObject);
                }
            }

            string readElement = "";
            while ((readElement = Console.ReadLine()) != "End")
            {
                for (int i = 0; i < trainersList.Count; i++)
                {
                    bool isElement = false;
                    for (int k = 0; k < trainersList[i].Pokemons.Count; k++)
                    {
                        if (trainersList[i].Pokemons[k].ElementPokemon == readElement)
                        {
                            trainersList[i].BadgesNum++;
                            isElement = true;
                            break;
                        }
                    }
                    if (isElement == false)
                    {
                        for (int k = 0; k < trainersList[i].Pokemons.Count; k++)
                        {
                            trainersList[i].Pokemons[k].HealthPokemon -= 10;
                        }
                        trainersList[i].Pokemons.RemoveAll(x => x.HealthPokemon <= 0);
                    }
                }
            }
            foreach (Trainer trainer in trainersList.OrderByDescending(x => x.BadgesNum))
                Console.WriteLine($"{trainer.TrainerName} {trainer.BadgesNum} {trainer.Pokemons.Count}");
        }
    }
}
