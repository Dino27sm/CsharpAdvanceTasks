﻿
using System.Collections.Generic;

namespace DefiningClasses
{
    public class Trainer
    {
        public Trainer(string trainerName, Pokemon getPokemon)
        {
            this.BadgesNum = 0;
            this.TrainerName = trainerName;
            this.Pokemons.Add(getPokemon);
        }
        public string  TrainerName { get; set; }
        public int BadgesNum { get; set; }
        public List<Pokemon> Pokemons { get; set; } = new List<Pokemon>();
    }
}
