﻿
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace DefiningClasses
{
    public class Family
    {
        private List<Person> people = new List<Person>();
        public void AddMember(Person member)
        {
            this.people.Add(member);
        }
        public Person GetOldestMember()
        {
            return people[people.FindIndex(x => x.Age == people.Select(y => y.Age).Max())];
        }
        public List<Person> GetListOfMembers()
        {
            return this.people;
        }
    }
}
