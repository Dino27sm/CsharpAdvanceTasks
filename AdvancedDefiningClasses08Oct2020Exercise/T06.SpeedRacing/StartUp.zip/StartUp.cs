﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Dictionary<string, Car> carData = new Dictionary<string, Car>();
            int numLines = int.Parse(Console.ReadLine());
            for (int i = 0; i < numLines; i++)
            {
                string[] readCars = Console.ReadLine().Split();
                string carModel = readCars[0];
                double carFuel = double.Parse(readCars[1]);
                double carFuelPerKm = double.Parse(readCars[2]);
                Car newCar = new Car(carModel, carFuel, carFuelPerKm);
                carData.Add(carModel, newCar);
            }

            string driveCommand = "";
            while ((driveCommand = Console.ReadLine()) != "End")
            {
                string[] commandParts = driveCommand.Split();
                string getModel = commandParts[1];
                double distanceToDrive = double.Parse(commandParts[2]);
                if (carData.ContainsKey(getModel))
                {
                    carData[getModel].DrveOn(distanceToDrive);
                }
            }
            foreach (var kvp in carData)
            {
                Console.WriteLine($"{kvp.Value.Model} {kvp.Value.FuelAmount:F2} {kvp.Value.TravelledDistance}");
            }
        }
    }
}
