﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    class Car
    {
        public Car(string model, double fuelAmount, double fuelConsumptionPerKilometer)
        {
            this.Model = model;
            this.FuelAmount = fuelAmount;
            this.FuelConsumptionPerKilometer = fuelConsumptionPerKilometer;
            this.TravelledDistance = 0.0;
        }
        public string Model { get; set; }
        public double FuelAmount { get; set; }
        public double FuelConsumptionPerKilometer { get; set; }
        public double TravelledDistance { get; set; }

        public double DrveOn(double driveDistance)
        {
            double distanceFuel = driveDistance * this.FuelConsumptionPerKilometer;
            if(this.FuelAmount >= distanceFuel)
            {
                this.TravelledDistance += driveDistance;
                this.FuelAmount -= distanceFuel;
            }
            else Console.WriteLine("Insufficient fuel for the drive");
            return this.TravelledDistance;
        }
    }
}
