﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Family familyMember = new Family();
            int numPersons = int.Parse(Console.ReadLine());
            for (int i = 0; i < numPersons; i++)
            {
                string[] readLine = Console.ReadLine().Split();
                string namePerson = readLine[0];
                int agePerson = int.Parse(readLine[1]);
                Person newMember = new Person(namePerson, agePerson);
                familyMember.AddMember(newMember);
            }
            Person oldestFamilyMember = familyMember.GetOldestMember();
            Console.WriteLine($"{oldestFamilyMember.Name} {oldestFamilyMember.Age}");
        }
    }
}
