﻿
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class Family
    {
        private List<Person> people = new List<Person>();

        public void AddMember(Person member)
        {
            this.people.Add(member);
        }

        public Person GetOldestMember()
        {
            int ageMax = int.MinValue;
            int indexMax = 0;
            for (int i = 0; i < people.Count; i++)
            {
                if (people[i].Age > ageMax)
                {
                    ageMax = people[i].Age;
                    indexMax = i;
                }
            }
            return people[indexMax];
        }
    }
}
