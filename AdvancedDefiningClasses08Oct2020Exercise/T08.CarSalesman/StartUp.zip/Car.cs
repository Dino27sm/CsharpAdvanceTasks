﻿using System.Text;

namespace DefiningClasses
{
    public class Car
    {
        public Car(string[] carData, Engine carEngine)
        {
            this.CarModel = carData[0];
            this.EngineData = carEngine;
            this.CarWeight = carData[2];
            this.CarColor = carData[3];
        }
        public string CarModel { get; set; }
        public Engine EngineData { get; set; }
        public string CarWeight { get; set; }
        public string CarColor { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{this.CarModel}:");
            sb.AppendLine($"  {this.EngineData.EngineModel}:");
            sb.AppendLine($"    Power: {this.EngineData.EnginePower}");
            sb.AppendLine($"    Displacement: {this.EngineData.Displacement}");
            sb.AppendLine($"    Efficiency: {this.EngineData.Efficiency}");
            sb.AppendLine($"  Weight: {this.CarWeight}");
            sb.AppendLine($"  Color: {this.CarColor}");
            return sb.ToString().Trim();
        }
    }
}
