﻿
namespace DefiningClasses
{
    public class Engine
    {
        public Engine(string[] engineData)
        {
            this.EngineModel = engineData[0];
            this.EnginePower = engineData[1];
            this.Displacement = engineData[2];
            this.Efficiency = engineData[3];
        }
        public string EngineModel { get; set; }
        public string EnginePower { get; set; }
        public string Displacement { get; set; }
        public string Efficiency { get; set; }
    }
}
