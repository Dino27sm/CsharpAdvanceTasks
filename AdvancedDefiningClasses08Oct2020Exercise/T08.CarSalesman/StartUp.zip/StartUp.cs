﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            List<Engine> engineList = new List<Engine>();
            int numEngines = int.Parse(Console.ReadLine());
            for (int i = 0; i < numEngines; i++)
            {
                string[] engineInfo = { string.Empty, string.Empty, "n/a", "n/a" };
                string[] readEngine = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                for (int k = 0; k < readEngine.Length; k++)
                {
                    engineInfo[k] = readEngine[k];
                }
                if (readEngine.Length > 2 && !char.IsDigit(readEngine[2][0]))
                {
                    engineInfo[2] = "n/a";
                    engineInfo[3] = readEngine[2];
                }
                Engine engineObject = new Engine(engineInfo);
                engineList.Add(engineObject);
            }

            List<Car> carList = new List<Car>();
            int numCars = int.Parse(Console.ReadLine());
            for (int i = 0; i < numCars; i++)
            {
                string[] carInfo = { string.Empty, string.Empty, "n/a", "n/a" };
                string[] readCar = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string engineType = readCar[1];
                for (int k = 0; k < readCar.Length; k++)
                {
                    carInfo[k] = readCar[k];
                }
                if (readCar.Length > 2 && !char.IsDigit(readCar[2][0]))
                {
                    carInfo[2] = "n/a";
                    carInfo[3] = readCar[2];
                }
                Engine thisCarEngine = engineList.FirstOrDefault(x => x.EngineModel == engineType);
                Car carObject = new Car(carInfo, thisCarEngine);
                carList.Add(carObject);
            }
            foreach (Car car in carList)
            {
                Console.WriteLine(car.ToString());
            }
        }
    }
}
